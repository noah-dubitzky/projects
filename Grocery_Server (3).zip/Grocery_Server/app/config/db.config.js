module.exports = {
	host: 'market-mapping-1.cd87dy7n86ul.us-east-1.rds.amazonaws.com',
	user: 'admin',
	password: 'Groceries',
	database: 'Grocer_Test'
};